import React from "react";
import "../css/movie_cart.css";
import CardImg from "../../images/1d6e7504-eb6a-4056-bac0-96fb51074153.jpg"
export default function movieCartCard() {

    return (
        <div className = "cardId">
            <div className="container">
                <div className="card cardImg">
                    <img className="card-img-top" src={CardImg} className = "img" alt="Card image"  />
                        <div className="card-body">
                            <h4 className="card-title cardHeader">The Bat Man</h4>
                            <div className = "row">
                                <div className="col-md-6 font-weight-bold">
                                    Duration
                                </div>
                                <div className="col-md-6">
                                    2h 30m
                                </div>
                                <div className="col-md-6 font-weight-bold">
                                    Theater
                                </div>
                                <div className="col-md-6">
                                    Vista-Light
                                </div>
                                <div className="col-md-6 font-weight-bold">
                                    Child-Task
                                </div>
                                <div className="col-md-6">
                                    <span className="mr-2">
                                        <button className = "btn btn-outline-primary btn-sm">
                                        <i className = "fa fa-minus"></i>
                                        </button>
                                    </span>
                                    2
                                    <span className="ml-2">
                                        <button className = "btn btn-outline-primary btn-sm">
                                        <i className = "fa fa-plus"></i>
                                        </button>
                                    </span>
                                </div>
                                <div className="col-md-6 font-weight-bold">
                                    Adult-Ticket
                                </div>
                                <div className="col-md-6">
                                    2h 30m
                                </div>
                                <div className="col-md-6 font-weight-bold">
                                    Payment
                                </div>
                                <div className="col-md-6">
                                    LKR 750.00
                                </div>
                            </div>
                            <button className="btn btn-sm float-right cardBtn mt-2">
                                Remove
                            </button>
                        </div>
                </div>
            </div>
        </div>
    );
}
