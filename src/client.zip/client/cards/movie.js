import React from "react";
import "../css/movie.css";
import CardImg from "../../images/1d6e7504-eb6a-4056-bac0-96fb51074153.jpg"
import StarImg from "../../images/star.png"

export default function movieCartCard() {
    return (
        <div className = "cardId">
            <div className="container">
                <div className="card cardImg">
                    <img className="card-img-top" src={CardImg} className = "img" alt="Card image"  />
                    <div className="card-body cardBody">
                        <h4 className="cardHeader text-uppercase">The Bat Man</h4>
                        <div class = "row">
                            <div className="col-md-5">
                                <h6 className = "cardSubHeader text-uppercase">NOW SCREENING</h6>
                            </div>
                            <div className="col-md-7">
                                <img className="subImg float-right" src={StarImg}  alt="Card image"  />
                                <img className="subImg float-right mr-2" src={StarImg}  alt="Card image"  />

                                <p classNAME = "float-right">8.1/10</p>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    );
}
